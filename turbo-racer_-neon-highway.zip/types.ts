
export enum GameStatus {
  START = 'START',
  PLAYING = 'PLAYING',
  FINISHED = 'FINISHED',
  CRASHED = 'CRASHED',
  SHOP = 'SHOP',
  PAUSED = 'PAUSED'
}

export enum GameMode {
  CAREER = 'CAREER',
  TIME_TRIAL = 'TIME_TRIAL',
  ENDLESS = 'ENDLESS'
}

export enum Weather {
  CLEAR = 'CLEAR',
  RAIN = 'RAIN',
  NIGHT = 'NIGHT',
  SUNSET = 'SUNSET'
}

export interface Upgrades {
  engine: number;
  tires: number;
  brakes: number;
  nitro: number;
}

export interface Car {
  x: number;
  y: number;
  width: number;
  height: number;
  speed: number;
  color: string;
  lane: number;
  health: number;
  nitro: number;
}

export interface Obstacle {
  x: number;
  y: number;
  type: 'cone' | 'breaker';
  width: number;
  height: number;
}

export interface GameState {
  status: GameStatus;
  mode: GameMode;
  level: number;
  coins: number;
  upgrades: Upgrades;
  playerColor: string;
  distance: number;
  targetDistance: number;
  speed: number;
  commentary: string;
  timeElapsed: number;
  weather: Weather;
}

export const GAME_WIDTH = 400;
export const GAME_HEIGHT = 600;
export const LANES = [80, 145, 210, 275];
export const BASE_FINISH_DISTANCE = 3000;
export const MAX_UPGRADE = 5;
