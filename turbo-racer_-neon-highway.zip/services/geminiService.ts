
import { GoogleGenAI } from "@google/genai";

// Fix: Correct initialization using named parameter and direct process.env.API_KEY as required by guidelines
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const getRaceCommentary = async (status: 'victory' | 'crash', score: number, time: number) => {
  try {
    const prompt = status === 'victory' 
      ? `The player just won the car race! Score: ${score}, Time: ${time.toFixed(1)}s. Write a short, high-energy victory quote (max 15 words) from a professional race announcer.`
      : `The player just crashed their car in a high-speed race. Write a witty or dramatic one-liner (max 15 words) from a disappointed race announcer.`;

    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
    });

    // Fix: Ensure correct usage of .text property directly (not as a method)
    return response.text || (status === 'victory' ? "Incredible finish! A new legend is born!" : "A devastating crash! Better luck next time.");
  } catch (error) {
    console.error("Gemini Error:", error);
    return status === 'victory' ? "Victory is yours!" : "Crash and burn!";
  }
};
