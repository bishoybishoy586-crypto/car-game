
import React, { useEffect, useRef } from 'react';
import { GameStatus, GAME_WIDTH, GAME_HEIGHT, LANES, Car, Weather, Upgrades, Obstacle } from '../types';

interface SideObject {
  x: number;
  y: number;
  type: 'tree' | 'pedestrian' | 'cyclist';
  size: number;
  color?: string;
  speed?: number;
}

interface Props {
  status: GameStatus;
  weather: Weather;
  upgrades: Upgrades;
  color: string;
  level: number;
  targetDistance: number;
  onFinish: (distance: number, time: number) => void;
  onCrash: (distance: number, time: number) => void;
  updateHUD: (speed: number, distance: number) => void;
  onPause: () => void;
  touchKeys: { [key: string]: boolean };
}

const GameCanvas: React.FC<Props> = ({ status, weather, upgrades, color, level, targetDistance, onFinish, onCrash, updateHUD, onPause, touchKeys }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const requestRef = useRef<number | null>(null);
  const frameRef = useRef(0);
  
  const playerRef = useRef<Car>({ x: LANES[1], y: 480, width: 40, height: 80, speed: 5, color: color, lane: 1, health: 100, nitro: 100 });
  const enemiesRef = useRef<Car[]>([]);
  const obstaclesRef = useRef<Obstacle[]>([]);
  const treesRef = useRef<SideObject[]>([]);
  const sidewalkEntitiesRef = useRef<SideObject[]>([]);
  const particlesRef = useRef<{x: number, y: number, vy: number}[]>([]);
  const distanceRef = useRef(0);
  const startTimeRef = useRef(0);
  const keysRef = useRef<{ [key: string]: boolean }>({});
  const roadOffsetRef = useRef(0);
  const spinRef = useRef(0);

  const initGame = () => {
    const startingSpeed = 6 + Math.min(level * 0.1, 4);
    playerRef.current = { x: LANES[1] + 5, y: 480, width: 40, height: 80, speed: startingSpeed, color: color, lane: 1, health: 100, nitro: 100 };
    enemiesRef.current = [];
    obstaclesRef.current = [];
    treesRef.current = [];
    sidewalkEntitiesRef.current = [];
    distanceRef.current = 0;
    startTimeRef.current = Date.now();
    roadOffsetRef.current = 0;
    spinRef.current = 0;
    
    for(let i=0; i<10; i++) {
        treesRef.current.push({
            x: Math.random() < 0.5 ? Math.random() * 20 : GAME_WIDTH - 25,
            y: Math.random() * GAME_HEIGHT,
            type: 'tree',
            size: 20 + Math.random() * 20
        });
    }

    if (weather === Weather.RAIN) {
      particlesRef.current = Array.from({ length: 50 }, () => ({
        x: Math.random() * GAME_WIDTH,
        y: Math.random() * GAME_HEIGHT,
        vy: 10 + Math.random() * 10
      }));
    }
  };

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => { 
      keysRef.current[e.key] = true; 
      if (e.key === 'p' || e.key === 'Escape') onPause();
    };
    const handleKeyUp = (e: KeyboardEvent) => { keysRef.current[e.key] = false; };
    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, [onPause]);

  const drawCar = (ctx: CanvasRenderingContext2D, car: Car, isPlayer: boolean) => {
    const { x, y, width, height } = car;
    ctx.save();
    
    const isRainbow = color === 'rainbow' || color === 'rgb';
    const hue = (frameRef.current * 2) % 360;
    const carColor = (isPlayer && isRainbow) ? `hsl(${hue}, 100%, 50%)` : (isPlayer ? color : car.color);

    if (isPlayer && spinRef.current > 0) {
      ctx.translate(x + width/2, y + height/2);
      ctx.rotate(spinRef.current);
      ctx.translate(-(x + width/2), -(y + height/2));
    }

    if (isPlayer) {
      ctx.shadowBlur = 20;
      ctx.shadowColor = carColor;
      ctx.fillStyle = 'rgba(0,0,0,0.1)';
      ctx.fillRect(x - 5, y - 5, width + 10, height + 10);
    }

    ctx.shadowBlur = 0;
    ctx.fillStyle = 'rgba(0,0,0,0.3)';
    ctx.fillRect(x + 4, y + 4, width, height);

    ctx.fillStyle = carColor;
    ctx.beginPath();
    ctx.roundRect(x, y, width, height, 8);
    ctx.fill();

    if (isPlayer) {
      ctx.fillStyle = 'rgba(255,255,255,0.3)';
      ctx.fillRect(x + width/2 - 8, y, 4, height);
      ctx.fillRect(x + width/2 + 4, y, 4, height);
    }

    ctx.fillStyle = '#111';
    ctx.fillRect(x + 6, y + 15, width - 12, 12);
    ctx.fillRect(x + 6, y + height - 25, width - 12, 10);

    const headlightColor = (isPlayer && isRainbow) ? `hsl(${hue}, 100%, 80%)` : '#fffaaa';
    ctx.shadowBlur = 15;
    ctx.shadowColor = headlightColor;
    ctx.fillStyle = headlightColor;
    ctx.fillRect(x + 4, y + 2, 10, 5);
    ctx.fillRect(x + width - 14, y + 2, 10, 5);

    ctx.shadowBlur = 10;
    ctx.shadowColor = '#f00';
    ctx.fillStyle = '#f00';
    ctx.fillRect(x + 4, y + height - 6, 10, 4);
    ctx.fillRect(x + width - 14, y + height - 6, 10, 4);

    if (isPlayer && (keysRef.current[' '] || touchKeys[' ']) && car.nitro > 0) {
      const flameColor = isRainbow ? `hsl(${(hue + 180)%360}, 100%, 50%)` : '#3b82f6';
      ctx.shadowBlur = 25;
      ctx.shadowColor = flameColor;
      ctx.fillStyle = flameColor;
      ctx.beginPath();
      ctx.moveTo(x + 10, y + height);
      ctx.lineTo(x + width/2, y + height + 35 + Math.random() * 10);
      ctx.lineTo(x + width - 10, y + height);
      ctx.fill();
    }
    ctx.restore();
  };

  const drawTree = (ctx: CanvasRenderingContext2D, tree: SideObject) => {
    const { x, y, size } = tree;
    ctx.fillStyle = '#4a2c2a';
    ctx.fillRect(x + size/2 - 4, y + size/2, 8, size/2);
    ctx.fillStyle = '#15803d';
    ctx.beginPath();
    ctx.arc(x + size/2, y + size/2, size/2, 0, Math.PI * 2);
    ctx.fill();
  };

  const spawnEntities = () => {
    const maxEnemies = Math.min(4 + Math.floor(level / 5), 8);
    const spawnProb = Math.min(0.02 + (level * 0.008), 0.15);
    const obstacleProb = Math.min(0.01 + (level * 0.003), 0.08);

    if (enemiesRef.current.length < maxEnemies && Math.random() < spawnProb) {
      const lane = Math.floor(Math.random() * 4);
      const enemySpeed = (3 + level * 0.5) + Math.random() * 4;
      
      const enemy: Car = {
        x: LANES[lane] + 5,
        y: -100,
        width: 40,
        height: 80,
        speed: enemySpeed,
        color: `hsl(${Math.random() * 360}, 60%, 50%)`,
        lane,
        health: 100,
        nitro: 0
      };
      
      if (!enemiesRef.current.some(e => e.lane === lane && Math.abs(e.y - enemy.y) < 200)) {
        enemiesRef.current.push(enemy);
      }
    }

    // Fixed: Only spawn cones now, removed oil
    if (obstaclesRef.current.length < 4 && Math.random() < obstacleProb) {
      obstaclesRef.current.push({
        x: 70 + Math.random() * (GAME_WIDTH - 140),
        y: -100,
        type: 'cone',
        width: 25,
        height: 25
      });
    }

    if (Math.random() < 0.05) {
        treesRef.current.push({
            x: Math.random() < 0.5 ? Math.random() * 15 : GAME_WIDTH - 20,
            y: -100,
            type: 'tree',
            size: 25 + Math.random() * 30
        });
    }
  };

  const gameLoop = () => {
    if (status !== GameStatus.PLAYING) return;
    frameRef.current++;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const player = playerRef.current;
    
    const isPressingLeft = keysRef.current['ArrowLeft'] || keysRef.current['a'] || touchKeys['ArrowLeft'];
    const isPressingRight = keysRef.current['ArrowRight'] || keysRef.current['d'] || touchKeys['ArrowRight'];
    const isPressingUp = keysRef.current['ArrowUp'] || keysRef.current['w'] || touchKeys['ArrowUp'];
    const isPressingDown = keysRef.current['ArrowDown'] || keysRef.current['s'] || touchKeys['ArrowDown'];
    const isPressingNitro = keysRef.current[' '] || touchKeys[' '];

    const handlingBase = 2.4 + (upgrades.tires * 0.4);
    const handling = handlingBase * (weather === Weather.RAIN ? 0.6 : 1.0);
    
    const levelBonus = Math.min(level * 0.2, 5);
    const cruisingSpeed = 10 + (upgrades.engine * 1.5) + levelBonus; 
    const maxSpeed = cruisingSpeed + 6; 
    const accel = 0.1 + (upgrades.engine * 0.03);
    const brake = 0.2 + (upgrades.brakes * 0.1);

    if (spinRef.current > 0) {
      spinRef.current += 0.2;
      if (spinRef.current > Math.PI * 2) spinRef.current = 0;
      player.speed *= 0.98;
    } else {
      if (isPressingLeft) player.x -= handling;
      if (isPressingRight) player.x += handling;
      
      let targetMax = isPressingUp ? maxSpeed : cruisingSpeed;
      
      if (isPressingNitro && player.nitro > 0) {
        targetMax *= 1.7;
        player.nitro -= 1.4;
      } else if (player.nitro < 100) {
        player.nitro += 0.12 * upgrades.nitro;
      }
      
      if (isPressingDown) {
        player.speed = Math.max(player.speed - brake, 3);
      } else if (player.speed < targetMax) {
        player.speed = Math.min(player.speed + accel, targetMax);
      } else if (player.speed > targetMax) {
        player.speed = Math.max(player.speed - 0.05, targetMax); 
      }
    }

    player.x = Math.max(70, Math.min(player.x, GAME_WIDTH - player.width - 70));
    distanceRef.current += player.speed;
    roadOffsetRef.current = (roadOffsetRef.current + player.speed) % 100;

    spawnEntities();
    enemiesRef.current.forEach((enemy, idx) => {
      enemy.y += player.speed - enemy.speed;
      if (Math.abs(player.x - enemy.x) < 36 && Math.abs(player.y - enemy.y) < 76) {
        onCrash(distanceRef.current, (Date.now() - startTimeRef.current) / 1000);
      }
      if (enemy.y > GAME_HEIGHT + 100 || enemy.y < -300) enemiesRef.current.splice(idx, 1);
    });

    obstaclesRef.current.forEach((obs, idx) => {
      obs.y += player.speed;
      if (Math.abs(player.x + 20 - (obs.x + obs.width/2)) < (20 + obs.width/2) &&
          Math.abs(player.y + 40 - (obs.y + obs.height/2)) < (40 + obs.height/2)) {
        // Fixed: Removed spin effect from oil, only handle cone collision (slow down)
        player.speed *= 0.6;
        obstaclesRef.current.splice(idx, 1);
      }
      if (obs.y > GAME_HEIGHT + 100) obstaclesRef.current.splice(idx, 1);
    });

    treesRef.current.forEach(tree => { tree.y += player.speed; });

    if (distanceRef.current >= targetDistance) {
      onFinish(distanceRef.current, (Date.now() - startTimeRef.current) / 1000);
    }
    updateHUD(Math.floor(player.speed * 15), Math.floor(distanceRef.current));

    const bgColors = {
      [Weather.CLEAR]: '#0f172a',
      [Weather.SUNSET]: '#1e1b4b',
      [Weather.NIGHT]: '#020617',
      [Weather.RAIN]: '#0f172a'
    };
    ctx.fillStyle = bgColors[weather];
    ctx.fillRect(0, 0, GAME_WIDTH, GAME_HEIGHT);

    ctx.fillStyle = '#064e3b';
    ctx.fillRect(0, 0, 30, GAME_HEIGHT);
    ctx.fillRect(GAME_WIDTH - 30, 0, 30, GAME_HEIGHT);

    ctx.fillStyle = '#1e293b';
    ctx.fillRect(30, 0, 35, GAME_HEIGHT);
    ctx.fillRect(GAME_WIDTH - 65, 0, 35, GAME_HEIGHT);

    const neonIntensity = 10 + Math.min(level, 15);
    const neonHue = (frameRef.current) % 360;
    ctx.shadowBlur = neonIntensity;
    ctx.shadowColor = `hsl(${neonHue}, 100%, 50%)`;
    ctx.fillStyle = `hsl(${neonHue}, 100%, 70%)`;
    ctx.fillRect(65, 0, 5, GAME_HEIGHT);
    ctx.fillRect(GAME_WIDTH - 70, 0, 5, GAME_HEIGHT);
    ctx.shadowBlur = 0;

    ctx.fillStyle = '#111827'; 
    ctx.fillRect(70, 0, GAME_WIDTH - 140, GAME_HEIGHT);

    ctx.setLineDash([40, 40]);
    ctx.lineDashOffset = -roadOffsetRef.current;
    ctx.strokeStyle = 'rgba(0, 255, 255, 0.4)';
    ctx.lineWidth = 2;
    for (let i = 1; i < 4; i++) {
      ctx.beginPath(); ctx.moveTo(70 + (i * 65), 0); ctx.lineTo(70 + (i * 65), GAME_HEIGHT); ctx.stroke();
    }
    ctx.setLineDash([]);

    treesRef.current.forEach(tree => drawTree(ctx, tree));

    // Fixed: Only draw cones, removed oil drawing logic
    obstaclesRef.current.forEach(obs => {
      ctx.fillStyle = '#ec4899';
      ctx.shadowBlur = 10; ctx.shadowColor = '#ec4899';
      ctx.beginPath(); ctx.moveTo(obs.x, obs.y + obs.height); ctx.lineTo(obs.x + obs.width/2, obs.y); ctx.lineTo(obs.x + obs.width, obs.y + obs.height); ctx.fill();
      ctx.shadowBlur = 0;
    });

    const distToFinish = targetDistance - distanceRef.current;
    if (distToFinish < GAME_HEIGHT) {
      const finishY = player.y - distToFinish;
      const size = 20;
      for (let x = 70; x < GAME_WIDTH - 70; x += size) {
        for (let y = 0; y < 40; y += size) {
          ctx.fillStyle = (Math.floor(x / size) + Math.floor(y / size)) % 2 === 0 ? 'white' : 'black';
          ctx.fillRect(x, finishY + y, size, size);
        }
      }
    }

    enemiesRef.current.forEach(e => drawCar(ctx, e, false));
    drawCar(ctx, player, true);

    if (weather === Weather.RAIN) {
      ctx.strokeStyle = 'rgba(100, 200, 255, 0.3)';
      ctx.lineWidth = 1;
      particlesRef.current.forEach(p => {
        ctx.beginPath(); ctx.moveTo(p.x, p.y); ctx.lineTo(p.x - 2, p.y + 15); ctx.stroke();
        p.y += p.vy; if (p.y > GAME_HEIGHT) p.y = -20;
      });
    }

    ctx.fillStyle = 'rgba(0,0,0,0.5)';
    ctx.fillRect(GAME_WIDTH - 25, GAME_HEIGHT - 120, 15, 100);
    ctx.shadowBlur = 10; ctx.shadowColor = '#3b82f6';
    ctx.fillStyle = '#3b82f6';
    ctx.fillRect(GAME_WIDTH - 25, GAME_HEIGHT - 20 - player.nitro, 15, player.nitro);
    ctx.shadowBlur = 0;

    requestRef.current = requestAnimationFrame(gameLoop);
  };

  useEffect(() => {
    if (status === GameStatus.PLAYING) {
      initGame();
      requestRef.current = requestAnimationFrame(gameLoop);
    } else {
      if (requestRef.current) cancelAnimationFrame(requestRef.current);
    }
    return () => { if (requestRef.current) cancelAnimationFrame(requestRef.current); };
  }, [status, weather, upgrades, color, level]);

  return <canvas ref={canvasRef} width={GAME_WIDTH} height={GAME_HEIGHT} className="bg-black cursor-none block w-auto h-full max-w-full" />;
};

export default GameCanvas;
