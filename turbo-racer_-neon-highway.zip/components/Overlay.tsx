
import React, { useState } from 'react';
import { GameStatus, GameState, GameMode, MAX_UPGRADE, BASE_FINISH_DISTANCE } from '../types';

interface Props {
  state: GameState;
  onStart: (mode: GameMode) => void;
  onUpgrade: (type: any) => void;
  onColorChange: (color: string) => void;
  onStatusChange: (status: GameStatus) => void;
  setLevel: (level: number) => void;
  onMobileInput?: (key: string, isActive: boolean) => void;
}

const Overlay: React.FC<Props> = ({ state, onStart, onUpgrade, onColorChange, onStatusChange, setLevel, onMobileInput }) => {
  const { status, coins, level, upgrades, playerColor, commentary, distance, targetDistance, speed, timeElapsed } = state;
  const [tab, setTab] = useState<'main' | 'shop' | 'customize'>('main');

  if (status === GameStatus.PAUSED) {
    return (
      <div className="absolute inset-0 z-50 flex flex-col items-center justify-center bg-black/80 backdrop-blur-md text-white">
        <h2 className="text-4xl font-black italic text-yellow-400 mb-8 animate-pulse">PAUSED</h2>
        <div className="flex flex-col gap-4 w-48">
          <button onClick={() => onStatusChange(GameStatus.PLAYING)} className="py-3 bg-yellow-500 text-black font-bold rounded-lg shadow-lg shadow-yellow-500/20">RESUME</button>
          <button onClick={() => onStatusChange(GameStatus.START)} className="py-3 bg-slate-700 text-white font-bold rounded-lg">QUIT RACE</button>
        </div>
      </div>
    );
  }

  if (status === GameStatus.START) {
    return (
      <div className="absolute inset-0 z-10 flex flex-col bg-slate-950 text-white overflow-hidden">
        <div className="p-4 sm:p-6 flex justify-between items-center border-b border-white/5 bg-slate-900/50">
          <div>
            <h1 className="text-2xl sm:text-3xl font-black italic text-transparent bg-clip-text bg-gradient-to-r from-yellow-400 via-pink-500 to-cyan-500 tracking-tighter">TURBO RACER</h1>
            <p className="text-[10px] text-slate-400 uppercase tracking-widest font-bold">RGB NEON HIGHWAY</p>
          </div>
          <div className="bg-slate-900 px-3 py-1 sm:px-4 sm:py-2 rounded-xl border border-white/10 flex items-center gap-2 shadow-inner">
            <i className="fas fa-coins text-yellow-400"></i>
            <span className="font-mono font-bold text-sm sm:text-base">{coins.toLocaleString()}</span>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto p-4 sm:p-6">
          {tab === 'main' && (
            <div className="space-y-6">
              {/* Manual Level Selector */}
              <div className="bg-gradient-to-br from-slate-900 to-slate-800 p-6 rounded-3xl border border-white/5 shadow-xl relative overflow-hidden group">
                <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-cyan-500 to-blue-500"></div>
                <div className="flex flex-col items-center">
                  <span className="text-[10px] font-black text-cyan-400 uppercase tracking-[0.2em] mb-4">Select Level</span>
                  <div className="flex items-center gap-8">
                    <button 
                      onClick={() => setLevel(Math.max(1, level - 1))}
                      className="w-12 h-12 rounded-2xl bg-slate-800/50 border border-white/10 flex items-center justify-center hover:bg-slate-700 hover:border-cyan-500/50 transition-all active:scale-90"
                    >
                      <i className="fas fa-minus text-slate-400 group-hover:text-cyan-400"></i>
                    </button>
                    <div className="text-center">
                      <div className="text-6xl font-black italic text-white drop-shadow-[0_0_15px_rgba(255,255,255,0.3)] leading-none mb-1">{level}</div>
                      <div className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">{targetDistance}M Race</div>
                    </div>
                    <button 
                      onClick={() => setLevel(level + 1)}
                      className="w-12 h-12 rounded-2xl bg-slate-800/50 border border-white/10 flex items-center justify-center hover:bg-slate-700 hover:border-cyan-500/50 transition-all active:scale-90"
                    >
                      <i className="fas fa-plus text-slate-400 group-hover:text-cyan-400"></i>
                    </button>
                  </div>
                </div>
              </div>

              <div className="bg-slate-900/50 p-4 rounded-2xl border border-white/5 italic text-xs sm:text-sm text-slate-400 text-center backdrop-blur-sm">
                "{commentary}"
              </div>

              <div className="flex flex-col gap-4">
                <button 
                  onClick={() => onStart(GameMode.CAREER)}
                  className="w-full py-5 bg-gradient-to-r from-yellow-500 to-yellow-400 hover:from-yellow-400 hover:to-yellow-300 text-black font-black text-xl rounded-2xl transition-all shadow-xl shadow-yellow-500/30 transform hover:scale-[1.02] active:scale-95 border-b-4 border-yellow-700"
                >
                  RACE NOW (LEVEL {level})
                </button>
                <div className="grid grid-cols-2 gap-4">
                  <button onClick={() => setTab('shop')} className="py-4 bg-slate-800 hover:bg-slate-700 rounded-2xl font-bold border border-white/5 flex items-center justify-center gap-2">
                    <i className="fas fa-tools text-yellow-500 text-xs"></i> SHOP
                  </button>
                  <button onClick={() => setTab('customize')} className="py-4 bg-slate-800 hover:bg-slate-700 rounded-2xl font-bold border border-white/5 flex items-center justify-center gap-2">
                    <i className="fas fa-palette text-cyan-500 text-xs"></i> GARAGE
                  </button>
                </div>
              </div>
            </div>
          )}

          {tab === 'shop' && (
            <div className="space-y-4">
              <button onClick={() => setTab('main')} className="text-sm font-bold text-slate-400 mb-4 flex items-center gap-2">
                <i className="fas fa-arrow-left"></i> BACK
              </button>
              <h3 className="text-xl font-bold text-yellow-400 italic uppercase">Upgrades</h3>
              {Object.entries(upgrades).map(([key, val]) => {
                const cost = val * 1000;
                return (
                  <div key={key} className="bg-slate-900 p-4 rounded-xl border border-white/5 flex justify-between items-center shadow-md">
                    <div>
                      <div className="text-[10px] uppercase font-bold text-slate-400">{key}</div>
                      <div className="flex gap-1 mt-1">
                        {Array.from({ length: MAX_UPGRADE }).map((_, i) => (
                          <div key={i} className={`w-3 h-1.5 rounded-full ${i < val ? 'bg-yellow-500 shadow-[0_0_5px_rgba(234,179,8,0.5)]' : 'bg-slate-800'}`}></div>
                        ))}
                      </div>
                    </div>
                    {val < MAX_UPGRADE ? (
                      <button 
                        onClick={() => onUpgrade(key)}
                        disabled={coins < cost}
                        className={`px-4 py-2 rounded-lg font-bold text-xs ${coins >= cost ? 'bg-white text-black hover:bg-yellow-400' : 'bg-slate-800 text-slate-500'}`}
                      >
                        ${cost}
                      </button>
                    ) : (
                      <span className="text-[10px] font-bold text-green-500 uppercase px-2 py-1 bg-green-500/10 rounded border border-green-500/20">MAXED</span>
                    )}
                  </div>
                );
              })}
            </div>
          )}

          {tab === 'customize' && (
            <div className="space-y-4">
              <button onClick={() => setTab('main')} className="text-sm font-bold text-slate-400 mb-4 flex items-center gap-2">
                <i className="fas fa-arrow-left"></i> BACK
              </button>
              <h3 className="text-xl font-bold text-cyan-400 italic uppercase">Paint Shop</h3>
              <div className="grid grid-cols-4 gap-3">
                <button 
                  onClick={() => onColorChange('rainbow')}
                  className={`w-full aspect-square rounded-xl border-4 flex items-center justify-center overflow-hidden relative ${playerColor === 'rainbow' ? 'border-white shadow-[0_0_15px_rgba(255,255,255,0.5)]' : 'border-white/10'}`}
                >
                  <div className="absolute inset-0 bg-gradient-to-br from-red-500 via-green-500 via-blue-500 to-pink-500 animate-[spin_3s_linear_infinite]"></div>
                  <span className="relative z-10 text-[8px] font-black text-white bg-black/40 px-1 rounded">RGB</span>
                </button>
                {['#ef4444', '#3b82f6', '#10b981', '#f59e0b', '#8b5cf6', '#ec4899', '#ffffff'].map(c => (
                  <button 
                    key={c}
                    onClick={() => onColorChange(c)}
                    style={{ backgroundColor: c }}
                    className={`w-full aspect-square rounded-xl border-4 transform transition-transform active:scale-90 ${playerColor === c ? 'border-yellow-400 shadow-lg shadow-yellow-500/50' : 'border-white/10'}`}
                  ></button>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    );
  }

  if (status === GameStatus.PLAYING) {
    const progress = Math.min((distance / targetDistance) * 100, 100);
    return (
      <div className="absolute inset-0 pointer-events-none z-10 select-none">
        <div className="p-4 flex justify-between items-start">
          <div className="flex flex-col gap-2">
            <div className="bg-black/80 px-4 py-2 rounded-xl border border-cyan-500/30 backdrop-blur-md flex flex-col items-center shadow-[0_0_15px_rgba(6,182,212,0.2)]">
              <div className="text-[8px] uppercase font-bold text-cyan-400 tracking-widest">Speed</div>
              <div className="text-2xl font-black italic text-white leading-tight">
                {speed} <span className="text-[10px] text-cyan-400">KM/H</span>
              </div>
            </div>
            <div className="bg-black/80 px-3 py-1 rounded-lg border border-yellow-500/30 flex items-center gap-2">
              <span className="text-[10px] font-bold text-yellow-500 uppercase">Level {level}</span>
            </div>
          </div>
          
          <div className="flex flex-col items-end w-1/2 max-w-[150px]">
             <div className="text-[8px] font-black text-pink-500 mb-1 uppercase tracking-tighter">PROGRESS</div>
            <div className="w-full h-2.5 bg-black/60 rounded-full overflow-hidden border border-white/10 backdrop-blur-sm shadow-inner">
              <div 
                className="h-full bg-gradient-to-r from-cyan-500 via-blue-500 to-pink-500 transition-all duration-300 shadow-[0_0_10px_rgba(236,72,153,0.5)]" 
                style={{ width: `${progress}%` }}
              />
            </div>
            <div className="text-[8px] font-bold text-slate-400 mt-1 uppercase italic">Goal: {targetDistance}M</div>
          </div>
        </div>

        <div className="absolute bottom-8 left-0 w-full px-6 flex justify-between items-end pointer-events-auto">
          <div className="flex gap-4">
            <button 
              onPointerDown={() => onMobileInput?.('ArrowLeft', true)}
              onPointerUp={() => onMobileInput?.('ArrowLeft', false)}
              onPointerLeave={() => onMobileInput?.('ArrowLeft', false)}
              className="w-16 h-16 sm:w-20 sm:h-20 bg-black/40 backdrop-blur-xl border border-cyan-500/50 rounded-2xl flex items-center justify-center active:scale-90 active:bg-cyan-500/20 transition-all shadow-[0_0_15px_rgba(6,182,212,0.1)]"
            >
              <i className="fas fa-chevron-left text-2xl text-cyan-400"></i>
            </button>
            <button 
              onPointerDown={() => onMobileInput?.('ArrowRight', true)}
              onPointerUp={() => onMobileInput?.('ArrowRight', false)}
              onPointerLeave={() => onMobileInput?.('ArrowRight', false)}
              className="w-16 h-16 sm:w-20 sm:h-20 bg-black/40 backdrop-blur-xl border border-cyan-500/50 rounded-2xl flex items-center justify-center active:scale-90 active:bg-cyan-500/20 transition-all shadow-[0_0_15px_rgba(6,182,212,0.1)]"
            >
              <i className="fas fa-chevron-right text-2xl text-cyan-400"></i>
            </button>
          </div>

          <div className="flex flex-col gap-4 items-end">
            <button 
              onPointerDown={() => onMobileInput?.(' ', true)}
              onPointerUp={() => onMobileInput?.(' ', false)}
              onPointerLeave={() => onMobileInput?.(' ', false)}
              className="w-16 h-16 sm:w-18 sm:h-18 bg-black/40 backdrop-blur-xl border border-pink-500/50 rounded-full flex flex-col items-center justify-center active:scale-90 active:bg-pink-500/20 transition-all shadow-[0_0_20px_rgba(236,72,153,0.2)] animate-pulse"
            >
              <i className="fas fa-bolt text-xl text-pink-400"></i>
              <span className="text-[8px] font-bold text-pink-400 uppercase">Nitro</span>
            </button>
            <button 
              onPointerDown={() => onMobileInput?.('ArrowUp', true)}
              onPointerUp={() => onMobileInput?.('ArrowUp', false)}
              onPointerLeave={() => onMobileInput?.('ArrowUp', false)}
              className="w-16 h-16 sm:w-20 sm:h-20 bg-black/40 backdrop-blur-xl border border-yellow-500/50 rounded-2xl flex items-center justify-center active:scale-90 active:bg-yellow-500/20 transition-all shadow-[0_0_15px_rgba(234,179,8,0.1)]"
            >
              <i className="fas fa-tachometer-alt text-2xl text-yellow-400"></i>
            </button>
          </div>
        </div>

        <button 
          onClick={() => onStatusChange(GameStatus.PAUSED)}
          className="absolute top-4 right-4 w-10 h-10 bg-black/60 border border-white/10 rounded-lg flex items-center justify-center pointer-events-auto active:scale-90"
        >
          <i className="fas fa-pause text-white text-xs"></i>
        </button>
      </div>
    );
  }

  return (
    <div className="absolute inset-0 z-20 flex flex-col items-center justify-center bg-slate-950 text-white p-6 text-center">
      <div className="mb-4">
        {status === GameStatus.FINISHED ? (
          <h2 className="text-5xl font-black italic text-transparent bg-clip-text bg-gradient-to-r from-yellow-400 to-green-500 drop-shadow-[0_0_10px_rgba(234,179,8,0.5)]">LEVEL CLEARED!</h2>
        ) : (
          <h2 className="text-5xl font-black italic text-red-500 drop-shadow-[0_0_10px_rgba(239,68,68,0.5)]">CRASHED</h2>
        )}
      </div>

      <div className="bg-slate-900/80 p-6 rounded-3xl border border-white/10 mb-6 w-full max-w-sm backdrop-blur-md">
        <div className="flex justify-between mb-4">
          <div className="text-left">
            <div className="text-[10px] font-bold text-slate-500 uppercase">Race Time</div>
            <div className="text-xl font-mono text-cyan-400">{timeElapsed.toFixed(2)}s</div>
          </div>
          <div className="text-right">
            <div className="text-[10px] font-bold text-slate-500 uppercase">Coins Earned</div>
            <div className="text-xl font-mono text-yellow-400">+{Math.floor(distance / 10) + (status === GameStatus.FINISHED ? 1000 : 0)}</div>
          </div>
        </div>
        <div className="h-px bg-white/5 w-full mb-4"></div>
        <p className="text-sm italic text-slate-300 leading-relaxed font-medium">"{commentary}"</p>
      </div>

      <button 
        onClick={() => onStatusChange(GameStatus.START)}
        className="w-full max-w-sm py-4 bg-white text-black font-black text-lg rounded-2xl active:scale-95 transition-transform hover:shadow-[0_0_20px_rgba(255,255,255,0.3)]"
      >
        CONTINUE
      </button>
    </div>
  );
};

export default Overlay;
