
import React, { useState, useEffect, useCallback, useRef } from 'react';
import { GameStatus, GameState, GameMode, Weather, Upgrades, BASE_FINISH_DISTANCE } from './types';
import GameCanvas from './components/GameCanvas';
import Overlay from './components/Overlay';
import { getRaceCommentary } from './services/geminiService';

const App: React.FC = () => {
  const [gameState, setGameState] = useState<GameState>(() => {
    const saved = localStorage.getItem('turbo_racer_save');
    if (saved) return JSON.parse(saved);
    return {
      status: GameStatus.START,
      mode: GameMode.CAREER,
      level: 1,
      coins: 500,
      upgrades: { engine: 1, tires: 1, brakes: 1, nitro: 1 },
      playerColor: 'rainbow',
      distance: 0,
      targetDistance: BASE_FINISH_DISTANCE,
      speed: 0,
      commentary: "Welcome to the underground circuit.",
      timeElapsed: 0,
      weather: Weather.CLEAR
    };
  });

  const touchKeysRef = useRef<{ [key: string]: boolean }>({});

  const handleTouchInput = (key: string, isActive: boolean) => {
    touchKeysRef.current[key] = isActive;
  };

  useEffect(() => {
    localStorage.setItem('turbo_racer_save', JSON.stringify(gameState));
  }, [gameState]);

  const timerRef = useRef<number | null>(null);

  const startGame = (mode: GameMode = GameMode.CAREER) => {
    const weatherList = [Weather.CLEAR, Weather.SUNSET, Weather.NIGHT, Weather.RAIN];
    const levelDistance = BASE_FINISH_DISTANCE + (gameState.level - 1) * 2000;
    
    setGameState(prev => ({
      ...prev,
      status: GameStatus.PLAYING,
      mode,
      distance: 0,
      targetDistance: levelDistance,
      speed: 0,
      timeElapsed: 0,
      commentary: `Level ${prev.level} Start! Distance: ${levelDistance}m`,
      weather: weatherList[(prev.level - 1) % weatherList.length]
    }));
  };

  const setLevel = (newLevel: number) => {
    if (newLevel < 1) return;
    setGameState(prev => ({
      ...prev,
      level: newLevel,
      targetDistance: BASE_FINISH_DISTANCE + (newLevel - 1) * 2000
    }));
  };

  const handleGameOver = useCallback(async (finalStatus: GameStatus.FINISHED | GameStatus.CRASHED, finalDistance: number, finalTime: number) => {
    const earnedCoins = Math.floor(finalDistance / 10) + (finalStatus === GameStatus.FINISHED ? 1000 : 0);
    
    setGameState(prev => {
      const isVictory = finalStatus === GameStatus.FINISHED;
      return { 
        ...prev, 
        status: finalStatus, 
        distance: finalDistance,
        timeElapsed: finalTime,
        coins: prev.coins + earnedCoins,
        level: isVictory ? prev.level + 1 : prev.level,
        commentary: isVictory ? `Level ${prev.level} Complete! You earned ${earnedCoins} coins.` : "Calculating stats..." 
      };
    });

    const type = finalStatus === GameStatus.FINISHED ? 'victory' : 'crash';
    const commentary = await getRaceCommentary(type, earnedCoins, finalTime);
    setGameState(prev => ({ ...prev, commentary }));
  }, []);

  const buyUpgrade = (type: keyof Upgrades) => {
    const cost = gameState.upgrades[type] * 1000;
    if (gameState.coins >= cost && gameState.upgrades[type] < 5) {
      setGameState(prev => ({
        ...prev,
        coins: prev.coins - cost,
        upgrades: { ...prev.upgrades, [type]: prev.upgrades[type] + 1 }
      }));
    }
  };

  const changeColor = (color: string) => {
    setGameState(prev => ({ ...prev, playerColor: color }));
  };

  useEffect(() => {
    if (gameState.status === GameStatus.PLAYING) {
      timerRef.current = window.setInterval(() => {
        setGameState(prev => ({ ...prev, timeElapsed: prev.timeElapsed + 0.1 }));
      }, 100);
    } else {
      if (timerRef.current) clearInterval(timerRef.current);
    }
    return () => { if (timerRef.current) clearInterval(timerRef.current); };
  }, [gameState.status]);

  return (
    <div className="relative w-full h-screen flex items-center justify-center bg-slate-950 overflow-hidden font-sans select-none">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-blue-900/10 via-slate-950 to-black pointer-events-none"></div>

      <div className="relative shadow-2xl border-0 sm:border-4 border-slate-800 rounded-none sm:rounded-xl overflow-hidden bg-black ring-0 sm:ring-8 ring-slate-900/50 max-h-screen">
        <GameCanvas 
          status={gameState.status} 
          weather={gameState.weather}
          upgrades={gameState.upgrades}
          color={gameState.playerColor}
          level={gameState.level}
          targetDistance={gameState.targetDistance}
          onFinish={(dist, time) => handleGameOver(GameStatus.FINISHED, dist, time)}
          onCrash={(dist, time) => handleGameOver(GameStatus.CRASHED, dist, time)}
          updateHUD={(speed, dist) => setGameState(prev => ({ ...prev, speed, distance: dist }))}
          onPause={() => setGameState(prev => ({ ...prev, status: GameStatus.PAUSED }))}
          touchKeys={touchKeysRef.current}
        />
        
        <Overlay 
          state={gameState} 
          onStart={startGame} 
          onUpgrade={buyUpgrade}
          onColorChange={changeColor}
          setLevel={setLevel}
          onStatusChange={(status) => setGameState(prev => ({ ...prev, status }))}
          onMobileInput={handleTouchInput}
        />
      </div>

      <div className="hidden xl:flex flex-col ml-12 w-80 space-y-6 text-white">
        <div className="bg-slate-900/90 p-6 rounded-2xl border border-slate-800 shadow-2xl backdrop-blur-xl">
          <h2 className="text-2xl font-black mb-4 text-yellow-400 italic">CAR STATS</h2>
          <div className="space-y-4">
            {Object.entries(gameState.upgrades).map(([key, val]) => (
              <div key={key}>
                <div className="flex justify-between text-xs uppercase font-bold text-slate-400 mb-1">
                  <span>{key}</span>
                  <span>LVL {val}</span>
                </div>
                <div className="w-full h-2 bg-slate-800 rounded-full overflow-hidden">
                  <div className="h-full bg-yellow-500" style={{ width: `${(val / 5) * 100}%` }}></div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default App;
